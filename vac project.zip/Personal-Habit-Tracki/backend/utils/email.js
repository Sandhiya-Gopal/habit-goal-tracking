const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});

async function sendWelcomeEmail(toEmail) {
    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: toEmail,
        subject: "Welcome to Personal Habit Tracker!",
        text: `Welcome to Personal Habit Tracker!

Your login was successful.

Thank you for using our application!`
    };

    await transporter.sendMail(mailOptions);
}

module.exports = sendWelcomeEmail;