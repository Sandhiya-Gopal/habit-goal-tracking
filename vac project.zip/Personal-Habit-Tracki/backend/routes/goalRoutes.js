const express = require("express");
const Goal = require("../models/Goal");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Add a new goal
router.post("/", authMiddleware, async (req, res) => {
    try {
        const { title, description, targetDate } = req.body;

        if (!title) {
            return res.status(400).json({
                message: "Goal title is required"
            });
        }

        const goal = new Goal({
            userId: req.user.id,
            title,
            description,
            targetDate
        });

        await goal.save();

        res.status(201).json({
            message: "Goal added successfully",
            goal
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

// Get user's goals
router.get("/", authMiddleware, async (req, res) => {
    try {
        const goals = await Goal.find({
            userId: req.user.id
        });

        res.status(200).json(goals);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

// Update goal progress
router.put("/:id", authMiddleware, async (req, res) => {
    try {
        const goal = await Goal.findOne({
            _id: req.params.id,
            userId: req.user.id
        });

        if (!goal) {
            return res.status(404).json({
                message: "Goal not found"
            });
        }

        if (req.body.progress !== undefined) {
            goal.progress = req.body.progress;

            if (goal.progress >= 100) {
                goal.progress = 100;
                goal.completed = true;
            }
        }

        if (req.body.title !== undefined) {
            goal.title = req.body.title;
        }

        if (req.body.description !== undefined) {
            goal.description = req.body.description;
        }

        if (req.body.targetDate !== undefined) {
            goal.targetDate = req.body.targetDate;
        }

        await goal.save();

        res.status(200).json({
            message: "Goal updated successfully",
            goal
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

// Delete a goal
router.delete("/:id", authMiddleware, async (req, res) => {
    try {
        const goal = await Goal.findOneAndDelete({
            _id: req.params.id,
            userId: req.user.id
        });

        if (!goal) {
            return res.status(404).json({
                message: "Goal not found"
            });
        }

        res.status(200).json({
            message: "Goal deleted successfully"
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

module.exports = router;