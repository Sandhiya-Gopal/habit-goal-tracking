const express = require("express");
const Habit = require("../models/Habit");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

// Add a new habit
router.post("/", authMiddleware, async (req, res) => {
    try {
        const { name, frequency } = req.body;

        if (!name) {
            return res.status(400).json({
                message: "Habit name is required"
            });
        }

        const habit = new Habit({
            userId: req.user.id,
            name,
            frequency: frequency || "Daily"
        });

        await habit.save();

        res.status(201).json({
            message: "Habit added successfully",
            habit
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

// Get user's habits
router.get("/", authMiddleware, async (req, res) => {
    try {
        const habits = await Habit.find({
            userId: req.user.id
        });

        res.status(200).json(habits);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

// Complete / update a habit
router.put("/:id", authMiddleware, async (req, res) => {
    try {
        const habit = await Habit.findOne({
            _id: req.params.id,
            userId: req.user.id
        });

        if (!habit) {
            return res.status(404).json({
                message: "Habit not found"
            });
        }

        if (req.body.completed === true && !habit.completed) {
            habit.streak++;
        }

        habit.completed = req.body.completed;

        await habit.save();

        res.status(200).json({
            message: "Habit updated successfully",
            habit
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

// Delete a habit
router.delete("/:id", authMiddleware, async (req, res) => {
    try {
        const habit = await Habit.findOneAndDelete({
            _id: req.params.id,
            userId: req.user.id
        });

        if (!habit) {
            return res.status(404).json({
                message: "Habit not found"
            });
        }

        res.status(200).json({
            message: "Habit deleted successfully"
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Server error"
        });
    }
});

module.exports = router;