const mongoose = require("mongoose");

const habitSchema = new mongoose.Schema(
    {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },

        name: {
            type: String,
            required: true,
            trim: true
        },

        frequency: {
            type: String,
            enum: ["Daily", "Weekly", "Monthly"],
            default: "Daily"
        },

        completed: {
            type: Boolean,
            default: false
        },

        streak: {
            type: Number,
            default: 0
        }
    },
    {
        timestamps: true
    }
);

module.exports = mongoose.model("Habit", habitSchema);