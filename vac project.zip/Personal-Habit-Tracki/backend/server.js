require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");

const connectDB = require("./db");
const authRoutes = require("./routes/authRoutes");
const habitRoutes = require("./routes/habitRoutes");
const goalRoutes = require("./routes/goalRoutes");

const app = express();
app.use(express.static(path.join(__dirname, "../frontend")));

const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Welcome message
app.get("/welcome", (req, res) => {
    res.send("Welcome to Personal Habit Tracker!");
});

// Authentication routes
app.use("/api", authRoutes);

// Habit routes
app.use("/api/habits", habitRoutes);

// goal routes
app.use("/api/goals", goalRoutes);

// Connect MongoDB
connectDB();

// Home route
app.get("/", (req, res) => {
    res.send("Personal Habit Tracking & Goal Management System Backend is Running!");
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

